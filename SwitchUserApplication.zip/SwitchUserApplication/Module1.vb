﻿Imports System.ServiceProcess
Module Module1
    Private Const SWITCH_USER_COMMAND As Int32 = 193
    Sub main()
        On Error Resume Next
        Dim sc As New System.ServiceProcess.ServiceController("Sus")
        sc.ExecuteCommand(SWITCH_USER_COMMAND)
    End Sub
End Module
