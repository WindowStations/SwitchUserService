﻿Imports System
Imports System.Collections.Generic
Imports System.Windows.Forms

Namespace suc
	Friend Module Program
		''' <summary>
		''' The main entry point for the application.
		''' </summary>
        <STAThread()> _
 Sub Main()
            Application.EnableVisualStyles()
            Application.SetCompatibleTextRenderingDefault(False)
            Application.Run(New SUApplicationContext())
        End Sub
	End Module
End Namespace
