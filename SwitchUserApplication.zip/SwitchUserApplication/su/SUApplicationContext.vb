﻿Imports MovablePython
Imports System
Imports System.Collections.Generic
Imports System.ServiceProcess
Imports System.Text
Imports System.Windows.Forms

Namespace suc
Friend Class SUApplicationContext
	Inherits ApplicationContext

	Private hk As Hotkey
	Private form As Form
	Private Const SWITCH_USER_COMMAND As Integer = 193
	Friend Sub New()
		' только создаем форму, она все равно нужна
		' чтобы слушать хоткеи
		form = New Form()
        End Sub
        Private Sub df()

            ' создаем и регистрируем глобайльный хоткей
            hk = New Hotkey(Keys.A, False, False, False, True)
		AddHandler hk.Pressed, Sub()
            SendSwitchCommand()
        End Sub
		If hk.GetCanRegister(form) Then
			hk.Register(form)
		End If

        ' Вешаем событие на выход
		AddHandler Application.ApplicationExit, AddressOf Application_ApplicationExit
	End Sub

        Private Sub SendSwitchCommand()
            ' Описываем нашу службу
            Dim sc As New ServiceController("Sus")
            Try
                ' посылаем ей команду
                sc.ExecuteCommand(SWITCH_USER_COMMAND)
            Catch ex As Exception
                MessageBox.Show(ex.Message)
            End Try
        End Sub

        Private Sub Application_ApplicationExit(ByVal sender As Object, ByVal e As EventArgs)
            ' при выходе разрегистрируем хоткей 
            If hk.Registered Then
                hk.Unregister()
            End If
        End Sub
    End Class
End Namespace
