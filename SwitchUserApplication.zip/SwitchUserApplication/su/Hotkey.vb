﻿'====================================================================================================
'The Free Edition of Instant VB limits conversion output to 100 lines per file.

'To purchase the Premium Edition, visit our website:
'https://www.tangiblesoftwaresolutions.com/order/order-instant-vb.html
'====================================================================================================

Imports System
Imports System.Windows.Forms
Imports System.ComponentModel
Imports System.Xml.Serialization
Imports System.Runtime.InteropServices

Namespace MovablePython
	Public Class Hotkey
		Implements IMessageFilter

		#Region "Interop"

		<DllImport("user32.dll", SetLastError := True)>
		Private Shared Function RegisterHotKey(ByVal hWnd As IntPtr, ByVal id As Integer, ByVal fsModifiers As UInteger, ByVal vk As Keys) As Integer
		End Function

		<DllImport("user32.dll", SetLastError:=True)>
		Private Shared Function UnregisterHotKey(ByVal hWnd As IntPtr, ByVal id As Integer) As Integer
		End Function

		Private Const WM_HOTKEY As UInteger = &H312

		Private Const MOD_ALT As UInteger = &H1
		Private Const MOD_CONTROL As UInteger = &H2
		Private Const MOD_SHIFT As UInteger = &H4
		Private Const MOD_WIN As UInteger = &H8

		Private Const ERROR_HOTKEY_ALREADY_REGISTERED As UInteger = 1409

		#End Region

		Private Shared currentID As Integer
		Private Const maximumID As Integer = &HBFFF

'INSTANT VB NOTE: The field keyCode was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private keyCode_Conflict As Keys
'INSTANT VB NOTE: The field shift was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private shift_Conflict As Boolean
'INSTANT VB NOTE: The field control was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private control_Conflict As Boolean
'INSTANT VB NOTE: The field alt was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private alt_Conflict As Boolean
'INSTANT VB NOTE: The field windows was renamed since Visual Basic does not allow fields to have the same name as other class members:
		Private windows_Conflict As Boolean

		<XmlIgnore>
		Private id As Integer
'INSTANT VB NOTE: The field registered was renamed since Visual Basic does not allow fields to have the same name as other class members:
		<XmlIgnore>
		Private registered_Conflict As Boolean
		<XmlIgnore>
		Private windowControl As Control

		Public Event Pressed As HandledEventHandler

		Public Sub New()
			Me.New(Keys.None, False, False, False, False)
			' No work done here!
		End Sub

		Public Sub New(ByVal keyCode As Keys, ByVal shift As Boolean, ByVal control As Boolean, ByVal alt As Boolean, ByVal windows As Boolean)
			' Assign properties
			Me.KeyCode = keyCode
			Me.Shift = shift
			Me.Control = control
			Me.Alt = alt
			Me.Windows = windows

			' Register us as a message filter
			Application.AddMessageFilter(Me)
		End Sub

		Protected Overrides Sub Finalize()
			' Unregister the hotkey if necessary
			If Me.Registered Then
				Me.Unregister()
			End If
		End Sub

		Public Function Clone() As Hotkey
			' Clone the whole object
			Return New Hotkey(Me.keyCode_Conflict, Me.shift_Conflict, Me.control_Conflict, Me.alt_Conflict, Me.windows_Conflict)
		End Function

		Public Function GetCanRegister(ByVal windowControl As Control) As Boolean
			' Handle any exceptions: they mean "no, you can't register" :)
			Try
				' Attempt to register
				If Not Me.Register(windowControl) Then
					Return False
				End If

				' Unregister and say we managed it
				Me.Unregister()
				Return True
			Catch e1 As Win32Exception
				Return False
			Catch e2 As NotSupportedException
				Return False
			End Try
		End Function

		Public Function GetCanRegister(ByVal windowControl As IntPtr) As Boolean
			' Handle any exceptions: they mean "no, you can't register" :)
			Try
				' Attempt to register
				If Not Me.Register(windowControl) Then
					Return False
				End If

				' Unregister and say we managed it
				Me.Unregister()
				Return True
			Catch e1 As Win32Exception
				Return False
			Catch e2 As NotSupportedException
				Return False
			End Try
		End Function

		Public Function Register(ByVal windowControl As Control) As Boolean
			' Check that we have not registered
			If Me.registered_Conflict Then
				Throw New NotSupportedException("You cannot register a hotkey that is already registered")
			End If

			' We can't register an empty hotkey
			If Me.Empty Then
				Throw New NotSupportedException("You cannot register an empty hotkey")
			End If

			' Get an ID for the hotkey and increase current ID
			Me.id = Hotkey.currentID
			Hotkey.currentID = Hotkey.currentID + 1 Mod Hotkey.maximumID

			' Translate modifier keys into unmanaged version
			Dim modifiers As UInteger = (If(Me.Alt, Hotkey.MOD_ALT, 0)) Or (If(Me.Control, Hotkey.MOD_CONTROL, 0)) Or (If(Me.Shift, Hotkey.MOD_SHIFT, 0)) Or (If(Me.Windows, Hotkey.MOD_WIN, 0))

			' Register the hotkey
			If Hotkey.RegisterHotKey(windowControl.Handle, Me.id, modifiers, keyCode_Conflict) = 0 Then
				' Is the error that the hotkey is registered?
				If Marshal.GetLastWin32Error() = ERROR_HOTKEY_ALREADY_REGISTERED Then
					Return False
				Else
					Throw New Win32Exception()
				End If
			End If

			' Save the control reference and register state
			Me.registered_Conflict = True
			Me.windowControl = windowControl

			' We successfully registered
			Return True
		End Function


'====================================================================================================
'End of the allowed output for the Free Edition of Instant VB.

'To purchase the Premium Edition, visit our website:
'https://www.tangiblesoftwaresolutions.com/order/order-instant-vb.html
'====================================================================================================
