﻿Imports System
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Data
Imports System.Diagnostics
Imports System.ServiceProcess
Imports System.Text
Imports System.Runtime.InteropServices
Imports System.Threading
Namespace su
    Partial Public Class Sus
        Inherits ServiceBase
        Private Const SWITCH_USER_COMMAND As Integer = 193
        Private Enum WTS_CONNECTSTATE_CLASS
            WTSActive
            WTSConnected
            WTSConnectQuery
            WTSShadow
            WTSDisconnected
            WTSIdle
            WTSListen
            WTSReset
            WTSDown
            WTSInit
        End Enum
        <StructLayout(LayoutKind.Sequential, CharSet:=CharSet.Auto)> _
  Private Structure WTS_SESSION_INFO
            Public SessionId As Integer
            Public pWinStationName As String
            Public State As WTS_CONNECTSTATE_CLASS
        End Structure
        <DllImport("wtsapi32.dll", CharSet:=CharSet.Auto)> _
  Private Shared Function WTSEnumerateSessions(ByVal hServer As IntPtr, <MarshalAs(UnmanagedType.U4)> ByVal Reserved As Integer, <MarshalAs(UnmanagedType.U4)> ByVal Version As Integer, ByRef ppSessionInfo As IntPtr, <MarshalAs(UnmanagedType.U4)> ByRef pCount As Integer) As Boolean
        End Function
        <DllImport("wtsapi32.dll")> _
  Private Shared Sub WTSFreeMemory(ByVal pMemory As IntPtr)
        End Sub
        <DllImport("wtsapi32.dll", SetLastError:=True)> _
  Private Shared Function WTSDisconnectSession(ByVal hServer As IntPtr, ByVal sessionId As Integer, ByVal bWait As Boolean) As Boolean
        End Function
        <DllImport("kernel32.dll", SetLastError:=True)> _
  Private Shared Function WTSGetActiveConsoleSessionId() As Integer
        End Function
        <DllImport("wtsapi32.dll", CharSet:=CharSet.Auto)> _
  Private Shared Function WTSConnectSession(ByVal TargetSessionId As UInt64, ByVal SessionId As UInt64, ByVal pPassword As String, ByVal bWait As Boolean) As Boolean
        End Function
        Private Shared ReadOnly WTS_CURRENT_SERVER_HANDLE As IntPtr = IntPtr.Zero
        Public Sub New()
            InitializeComponent()
        End Sub
        Protected Overrides Sub OnCustomCommand(ByVal command As Integer)
            MyBase.OnCustomCommand(command)
            If command = SWITCH_USER_COMMAND Then
                SwitchUser()
            End If
        End Sub
        Private Sub SwitchUser()
            Dim buffer As IntPtr = IntPtr.Zero
            Dim count As Integer = 0
            If WTSEnumerateSessions(WTS_CURRENT_SERVER_HANDLE, 0, 1, buffer, count) Then
                Dim sessionInfo(count - 1) As WTS_SESSION_INFO
                For index As Integer = 0 To count - 1
                    sessionInfo(index) = DirectCast(Marshal.PtrToStructure(New IntPtr(CInt(buffer) + (Marshal.SizeOf(New WTS_SESSION_INFO()) * index)), GetType(WTS_SESSION_INFO)), WTS_SESSION_INFO)
                Next
                Dim activeSessId As Integer = -1
                Dim targetSessId As Integer = -1
                For i As Integer = 1 To count - 1
                    If sessionInfo(i).State = WTS_CONNECTSTATE_CLASS.WTSDisconnected Then
                        targetSessId = sessionInfo(i).SessionId
                    ElseIf sessionInfo(i).State = WTS_CONNECTSTATE_CLASS.WTSActive Then
                        activeSessId = sessionInfo(i).SessionId
                    End If
                Next
                If (activeSessId > 0) AndAlso (targetSessId > 0) Then
                    WTSConnectSession(CULng(targetSessId), CULng(activeSessId), "", False)
                Else
                    WTSDisconnectSession(WTS_CURRENT_SERVER_HANDLE, activeSessId, False)
                End If
            End If
            WTSFreeMemory(buffer)
        End Sub
    End Class
End Namespace
