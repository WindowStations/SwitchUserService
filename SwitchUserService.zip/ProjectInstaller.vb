﻿Imports System
Imports System.Collections
Imports System.Collections.Generic
Imports System.ComponentModel
Imports System.Configuration.Install
Namespace sus
    <RunInstaller(True)> _
 Partial Public Class ProjectInstaller
        Inherits System.Configuration.Install.Installer
        Public Sub New()
            InitializeComponent()
        End Sub
        Private Sub serviceProcessInstaller1_AfterInstall(ByVal sender As Object, ByVal e As InstallEventArgs) Handles serviceProcessInstaller1.AfterInstall
        End Sub
        Private Sub serviceInstaller1_AfterInstall(ByVal sender As Object, ByVal e As InstallEventArgs) Handles serviceInstaller1.AfterInstall
        End Sub
    End Class
End Namespace
