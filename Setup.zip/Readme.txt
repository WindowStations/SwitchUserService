Use in.bat to install the Windows Service.  Right click, Run as administrator.
Use un.bat to uninstall.  Run as admin.
Use SwitchUsers.exe to trigger the service to initiate a direct switch to the previous user account.
Pin to SwitchUsers.exe to the taskbar or startmenu on both accounts.

This sample was converted from a C# example found here https://github.com/indomit/vfsus